from lerobot.common.robots.so101_follower import SO101Follower, SO101FollowerConfig

config = SO101FollowerConfig(
    port="/dev/ttyACM0",
    id="robot",
)
follower = SO101Follower(config)
follower.connect()

#shoulder_pan.pos/shoulder_lift.pos/elbow_flex.pos/wrist_flex.pos/wrist_roll.pos/gripper.pos
follower.send_action({"gripper.pos": 100})
print(follower.get_observation())