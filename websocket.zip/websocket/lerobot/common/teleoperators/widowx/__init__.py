from .config_widowx import WidowXConfig
from .widowx import WidowX
